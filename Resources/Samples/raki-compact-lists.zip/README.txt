Sample patch bundle shipped with Raki. Replace with real content.
